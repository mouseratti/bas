import xlrd,re

book = xlrd.open_workbook('tabel.xls')
listNames = book.sheet_names()
monthPattern = re.compile('.*Месяц:\s+([А-Я]+|[а-я]+)')

def getMonths(*l1):

	for c_e in l1[1]:
		monnth = re.search(monthPattern,str(c_e))
		if monnth:
			return monnth.group(1)

def getUsers(*l1):
	users=list()

	for c_e in range(len(l1)):
		if re.search('.*(РПО)',l1[c_e][2]):
			users.append(l1[c_e][1])
	
	return users
	


def getDays(*mass):

	days = (mass[3])
	#print(days)

	users = mass[-1::]
	first = mass[::-1]

	#print(first)

	for c_e in range(len(mass[0])):
		for c_ee in range(len(users[0])):
			if users[0][c_ee] ==  mass[c_e][1]:
				for c_eee in range(len(days)):
					if days[c_eee]:
						if  mass[c_e][c_eee] == 8.0:
							print (users[0][c_ee],' == ', mass[c_e][1],' == ', days[c_eee],' == ', mass[c_e][c_eee])
			#print( mass[c_e][0],' + ',mass[c_e][1] )
		


def osn(sheetInt):
	l1 = list()

	sheet=book.sheet_by_name(sheetInt)

	for rownum in range(sheet.nrows):
		row = sheet.row_values(rownum)
		l1.append(row)

	month=getMonths(*l1)
	print(month)

	users=getUsers(*l1)
	#print(users)

	l1.append(users)

	getDays(*l1)




for ii in listNames:
	#print(ii)
	osn(ii)

